# Scale

The `size` prop picks a step on a scale rather than a measurement. `size="2"` asks for the second
step, and the theme decides what that step is worth for the current density and the input the
person uses.

The same number can mean different things on different components, because each component
measures something different. On a `Button`, size sets the height of the control. On `Text`, it
sets how large the words are.

## Sizes are steps

A size 2 `Button` is 32 pixels tall at default density with a mouse, and 44 pixels tall with
touch. You don't write either number, so your code stays the same when the numbers change.

Controls accept `"1"` to `"4"`, and `Text` and `Heading` accept `"1"` to `"9"`. There's no
`size="2.5"` and no way to pass a length. If one screen could invent a value between two steps,
sizes would stop matching across your app.

Components use one of three scales:

- **Height:** `Button`, `TextField`, `Select` and the other controls that hold a label or a value.
- **Padding and corner:** `Card` and `Surface`.
- **Mark:** `Checkbox`, `Radio`, `Switch` and the handle of a `Slider`.

So `size="3"` on a `Card` and `size="3"` on a `Button` are not the same size. Choose the size that
looks right for each component rather than matching the numbers.

## One size sets the whole control

When you set `size` on a control, it gets a set of values chosen to work together: its height,
side padding, corner, icon size, the gap between icon and label, and the size of the label text.
Every combination of density and input has its own values, written out in full. The
[Layout](/foundations/layout) chapter explains why density uses chosen values.

The height is a minimum, not a fixed value. When a person zooms text to 200%, or a label wraps,
the control grows and does not cut off its text. WCAG 2.2 Success Criterion 1.4.4 requires that
text resizes without loss, so this is a floor.

## Checkboxes, radios and switches

A checkbox, a radio, a switch and a slider handle sit next to their label instead of holding one,
so they use a separate mark scale. A checkbox is exactly as tall as one line of the text beside
it, so it lines up with its label and grows when the text grows. A switch's track is one step
larger, so its round handle is close to the size of the checkbox beside it.

### Space stacked checkboxes 12 pixels apart

A checkbox is small, so its tappable area extends past the box you see, to the height of a
`Button` of the same size, up to 44 pixels. If two checkboxes sit closer than 12 pixels, the
lower one's tappable area covers part of the upper one, and a tap on one changes the other.

`gap="4"` gives 12 pixels at default density, but only 8 pixels at compact density. Use
`gap="5"`, which is at least 12 pixels at every density.

```tsx
<Stack gap="5">
  <Flex render={<label />} align="center" gap="3">
    <Checkbox size="2" />
    <Text size="3">Notify me when it ships</Text>
  </Flex>
  <Flex render={<label />} align="center" gap="3">
    <Checkbox size="2" />
    <Text size="3">Send the weekly digest</Text>
  </Flex>
</Stack>
```

## Sizes for touch

The `pointer` setting on a `Theme` accepts `fine`, `coarse` or `auto`. `fine` is for a mouse or
trackpad, and `coarse` is for a finger. With `auto`, the default, the theme reads the primary
input, not the width of the window. A narrow browser window with a mouse still uses the `fine`
values.

With touch, control heights, padding, icons, corners, marks and body text all grow. The spacing
between components stays the same, because a screen you touch often has no room to spare.

### Minimum and default tap sizes

WCAG 2.2 Success Criterion 2.5.8 (Level AA) sets a minimum target of 24 by 24 CSS pixels, and no
control in the system is smaller. The smallest control, size 1 at compact density with a mouse,
is exactly 24 pixels tall.

With touch, a size 2 control at default density is 44 pixels tall. That matches Success Criterion
2.5.5 (Level AAA) and Apple's default for iPhone and iPad, both 44 by 44. Studies of thumb use
put a reliable target near 9 to 10 millimetres (Parhi, Karlson and Bederson, 2006). A touch
control is smaller than 44 pixels only at size 1 or compact density, and it stays above Apple's
28-point minimum.

Set `coarse` on a laptop to check the touch sizes, including the larger text. To check the narrow
layout, make the window narrow.

```tsx
<Theme pointer="coarse">
  <Button size="2">Continue</Button>
</Theme>
```

## Buttons inside a field

When you put a `Button` inside a `TextField`, leave its `size` off. The field sets the button's
height from its own, so the button sits inside the field with an even gap around it. The
button's tappable area is its own box inside the field, and it does not grow to 44 pixels.

```tsx
<TextField
  size="3"
  type="password"
  placeholder="Password"
  trailing={<Button emphasis="quiet">Show</Button>}
/>
```

## Components with no size

`Progress` has no `size` prop. It has one thickness and takes the width of its container. `Code`
has an optional `size`, and without it the code takes the size of the text around it.
