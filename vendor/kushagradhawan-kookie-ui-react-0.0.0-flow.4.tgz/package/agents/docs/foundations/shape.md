# Shape

The `radius` setting on your Theme decides how round your whole app is. Each kind of component
works out its own corner from that one setting, so a button can become a pill while the card
around it stays a card. No component accepts a corner prop.

## Set the radius once, on the Theme

```tsx
<Theme radius="medium">
  <App />
</Theme>
```

`radius` accepts `none`, `small`, `medium`, `large` and `full`. The default is `full`, which
makes buttons, fields and menu rows into pills while cards keep the corners of `large`.
```tsx
import {
  Button,
  Checkbox,
  Flex,
  Radio,
  RadioGroup,
  Stack,
  Switch,
  Text,
  TextField,
  Theme,
} from "@kushagradhawan/kookie-ui-react";

const LEVELS = ["none", "small", "medium", "large", "full"] as const;

// Each row sets a different `radius` on a nested Theme. The radio and the switch stay round at
// `none`, and the checkbox stops short of a circle at `full`.
export default function Example() {
  return (
    <Stack gap="5" style={{ minWidth: "18rem" }}>
      {LEVELS.map((radius) => (
        <Theme key={radius} radius={radius}>
          <Flex gap="3" align="center" wrap="wrap">
            <Text size="2" emphasis="medium">
              {radius}
            </Text>
            <Button emphasis="loud">Save</Button>
            <TextField placeholder="Name" aria-label={`Name, ${radius}`} />
            <Checkbox defaultChecked aria-label={`Checkbox, ${radius}`} />
            <RadioGroup defaultValue="on" aria-label={`Radio, ${radius}`}>
              <Radio value="on" aria-label={`Option, ${radius}`} />
            </RadioGroup>
            <Switch defaultChecked aria-label={`Switch, ${radius}`} />
          </Flex>
        </Theme>
      ))}
    </Stack>
  );
}
```
Each value is a chosen set of corners, so `full` can make a button a pill and keep a dialog a
rectangle. One large number multiplied across every component could not do both.

The setting lives on the Theme rather than on each component because roundness only reads as
part of the product when every screen agrees. If one card could be rounder than the next, the
corner would stop telling you anything. This is a judgment.

## Use the token for the kind of component

The theme publishes a separate set of corners for each of five kinds of element:

```css
--radius-control-2   /* a size 2 button, text field or select trigger */
--radius-surface-2   /* a size 2 card */
--radius-overlay-2   /* a size 2 dialog */
--radius-row-2       /* a size 2 menu or select row */
--radius-mark-2      /* a size 2 checkbox */
```

In your own CSS, write the token for the kind of element you are building, and never a raw step
from the palette. Two kinds can have the same value at one setting and different values at
another, and the wrong token gives you the wrong shape with no error.

The sets are separate because a corner has to be about the same fraction of its box to look the
same. A checkbox is much smaller than a button, so a button's corner would turn the checkbox
into a circle.

Control corners also change with `density`, because a denser control is smaller. Card and dialog
corners change only with the `size` of the component, because density changes a card's padding
rather than its box.

## Corners that fit inside each other

When one rounded shape sits inside another, the two curves look right only if they share a
centre. Otherwise the inner corner cuts into the outer one or leaves a visible gap. The system
works this out for you in two places:

- **Panels with rows:** The corner of a `Menu` or `Select` list equals the corner of its rows
  plus the panel's padding.
- **Nested cards:** A `Card` inside another `Card` or a `Surface` takes the outer corner minus
  the outer padding, so it is always a little squarer than its container.

You never supply an offset. At `none`, there is no curve to fit, so nothing gains a corner from
its padding.

A `Dialog` takes the corner of a card one size larger, so it is rounder than the cards you put
inside it. This is a judgment, not a concentric rule.

## Shapes that stay round

`none` squares everything, pills included, except a few shapes whose roundness is part of what
they mean:

- **Radio:** A radio stays a circle, because a square radio looks like a checkbox.
- **Slider handle and switch thumb:** These stay circles, because a round handle is the shape
  people expect to drag. This is a judgment.
- **Switch track:** The track stays a capsule, because a round thumb only fits inside a curved
  track.
- **Avatar and Badge:** These stay round, because a circle marks a person or a count. This is a
  judgment.

The rule also works in the other direction. At `full`, a checkbox stops at the corner it has at
`large`, because a round checkbox looks like a radio.

## Change the corner for one region

To give one region a different corner, nest a Theme with its own `radius` on an element that
your layout already has, as each row of the example above does. Everything inside the region
takes the new corners, apart from the shapes listed above.
